//Név: Róth József
//Csoport: I/1/N
//Dátum: 2023.05.11.

public class BemenetEllenorzo {
    
    public static boolean testInput(double hossz, double szelesseg, double magassag) {

        System.out.println("Név: Róth Jószef");
        System.out.println("Csoport: SZOFT I/1/N");
        System.out.println("Dátum: 2023.05.11.");
        
        return hossz > 0 && szelesseg > 0 && magassag > 0;
    }
}